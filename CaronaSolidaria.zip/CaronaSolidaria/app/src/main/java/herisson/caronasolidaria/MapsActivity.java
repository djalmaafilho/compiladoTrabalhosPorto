package herisson.caronasolidaria;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.facebook.Profile;
import com.facebook.login.LoginManager;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;


public class MapsActivity extends FragmentActivity {

    private GoogleMap mMap;
    private LoginManager loginManager;
    private LocationManager locationManager;
    private Profile profile = Profile.getCurrentProfile();;

    ImageView icon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        setUpMapIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #setUpMap()} once when {@link #mMap} is not null.
     * <p>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not
     * have been completely destroyed during this process (it is likely that it would only be
     * stopped or paused), {@link #onCreate(Bundle)} may not be called again so we should call this
     * method in {@link #onResume()} to guarantee that it will be called.
     */
    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     * This is where we can add markers or lines, add listeners or move the camera. In this case, we
     * just add a marker near Africa.
     * <p>
     * This should only be called once and when we are sure that {@link #mMap} is not null.
     */
    private void setUpMap() {
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.setMyLocationEnabled(false);
        mMap.getUiSettings().setZoomGesturesEnabled(true);

        startGPS();

    }

    //OBTEM A LOCALIZACAO ATUAL ATRAVÉS DO GPS
    public void startGPS() {
        // Getting LocationManager object from System Service LOCATION_SERVICE
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // Creating a criteria object to retrieve provider
        Criteria criteria = new Criteria();

        // Getting the name of the best provider
        String provider = locationManager.getBestProvider(criteria, true);

        // Getting Current Location
        Location location = locationManager.getLastKnownLocation(provider);

        LocationListener locationListener = new LocationListener(){
            public void onLocationChanged(Location location) {
                // redraw the marker when get location update.
                drawMarker(location);
            }
            public void onProviderDisabled(String provider) {}
            public void onProviderEnabled(String provider) {}
            public void onStatusChanged(String provider, int status, Bundle extras) {}
        };

        if(location!=null){
            drawMarker(location);
        }
        locationManager.requestLocationUpdates(provider, 20000, 0, locationListener);
    }

    //CONFIGURACAO DO MARCADOR DA LOCALIZAÇÃO ATUAL
    private void drawMarker(Location location) {

        mMap.clear();

        final LatLng currentPosition = new LatLng(location.getLatitude(),location.getLongitude());

        final MarkerOptions markerOp = new MarkerOptions()
                .position(currentPosition)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                .anchor(0.5f, 1)
                .title(profile.getFirstName());

        final Marker myMarker = mMap.addMarker(markerOp);

        icon = (ImageView) findViewById(R.id.imageView);

        Picasso.with(MapsActivity.this).load(profile.getProfilePictureUri(50, 50)).into(icon, new Callback() {

            @Override
            public void onSuccess() {
                myMarker.setIcon(BitmapDescriptorFactory.fromBitmap(((BitmapDrawable)icon.getDrawable()).getBitmap()));
                myMarker.showInfoWindow();
            }

            @Override
            public void onError() {
                Log.e(getClass().getSimpleName(), " error loading thumbnail");
            }
        });


    CameraPosition cameraPosition = CameraPosition.builder()
                .target(currentPosition)
                .zoom(15)
                .build();

        // Animate the change in camera view over 2 seconds
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition),
                2000, null);
    }

    //OBTEM A INSTANCIA DE LOGIN DO FACEBOOK
    LoginManager getLoginManager() {
        if (loginManager == null) {
            loginManager = LoginManager.getInstance();
        }
        return loginManager;
    }

    //EVENTO DO CLICK DO BOTÃO DE SAIR EXIBINDO UMA DIALOG DE CONFIRMACAO
    public void logOutClick(View view) {

        String logout = getResources().getString(
                com.facebook.R.string.com_facebook_loginview_log_out_action);
        String cancel = getResources().getString(
                com.facebook.R.string.com_facebook_loginview_cancel_action);
        String message;

        if (profile != null && profile.getName() != null) {
            message = String.format(
                    getResources().getString(
                            com.facebook.R.string.com_facebook_loginview_logged_in_as),
                    profile.getName());
        } else {
            message = getResources().getString(
                    com.facebook.R.string.com_facebook_loginview_logged_in_using_facebook);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        builder.setMessage(message)
                .setCancelable(true)
                .setPositiveButton(logout, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(MapsActivity.this, LoginActivity.class);
                        startActivity(i);
                        getLoginManager().logOut();
                    }
                }).setNegativeButton(cancel, null);

        builder.create().show();
    }


    public void oferecerClick(View view){

    }

    public void procurarClick(View view){

    }

    @Override
    public void onBackPressed() {

    }
}
