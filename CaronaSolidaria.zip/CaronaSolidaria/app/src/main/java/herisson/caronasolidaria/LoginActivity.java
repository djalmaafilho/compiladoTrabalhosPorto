package herisson.caronasolidaria;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends Activity {


    // UI references.
    private View mProgressView;
    private View mLoginFormView;

    private CallbackManager callbackManager;
    private LoginButton loginButton;
    private AccessTokenTracker accessTokenTracker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        //Obter hash gerado pelo sistema
        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "herisson.caronasolidaria",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }

        conFacebook();


    }


    protected void conFacebook()
    {

        FacebookSdk.sdkInitialize(getApplicationContext());
        callbackManager = CallbackManager.Factory.create();

        accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken newAccessToken) {

            }
        };

        setContentView(R.layout.activity_login);

        if (AccessToken.getCurrentAccessToken() != null) {

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    Intent i = new Intent(LoginActivity.this, MapsActivity.class);
                    startActivity(i);

                    finish();
                }
            },1000);

        }

        loginButton = (LoginButton)findViewById(R.id.login_button);
        loginButton.setReadPermissions(Arrays.asList("email", "public_profile", "user_friends"));


        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            Bundle b = new Bundle();

            @Override
            public void onSuccess(LoginResult loginResult) {

                //b.putString("Id", loginResult.getAccessToken().getUserId());
                //b.putString("Token", loginResult.getAccessToken().getToken());

                Intent it = new Intent(LoginActivity.this, MapsActivity.class);

                //it.putExtra("dados", b);

                startActivity(it);

            }

            @Override
            public void onCancel() {
                if (!existeConexao()) {
                    showToast("Verifique sua conexão!");
                } else {
                    showToast("Login cancelado.");
                }


            }

            @Override
            public void onError(FacebookException e) {
                if (!existeConexao()) {
                    showToast("Verifique sua conexão!");
                } else {
                    showToast("Login falhou.");
                }
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        accessTokenTracker.stopTracking();
    }

    private void showToast(final String s) {
        final Context ctx = LoginActivity.this;
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show();
            }
        });

    }

    public boolean existeConexao(){
        ConnectivityManager connectivity = (ConnectivityManager)
                this.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo netInfo = connectivity.getActiveNetworkInfo();

            // Se não existe nenhum tipo de conexão retorna false
            if (netInfo == null) {
                return false;
            }

            int netType = netInfo.getType();

            // Verifica se a conexão é do tipo WiFi ou Mobile e
            // retorna true se estiver conectado ou false em
            // caso contrário
            if (netType == ConnectivityManager.TYPE_WIFI ||
                    netType == ConnectivityManager.TYPE_MOBILE) {
                return netInfo.isConnected();

            } else {
                return false;
            }
        }else{
            return false;
        }
    }

    @Override
    public void onBackPressed() {

    }
}

